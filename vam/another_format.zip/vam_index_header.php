<?php
/**
 * @Project: Vacation Air Virtual Airlines
 * @Author: [Your Name]
 * @Web [Your Website]
 * Copyright (c) 2023 Vacation Air
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Vacation Air</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- Custom CSS -->
    <style>
        :root {
            --vacation-primary: #0d47a1;  /* Azul oscuro principal */
            --vacation-secondary: #1565c0; /* Azul medio */
            --vacation-accent: #1e88e5;   /* Azul claro */
            --vacation-green: #2e7d32;    /* Verde oscuro */
            --vacation-light: #f5f9fc;
            --vacation-dark: #0a2e5a;     /* Azul muy oscuro */
            --vacation-text-light: #e3f2fd;
            --vacation-text-dark: #0d47a1;
            --vacation-blue: #1e88e5;
            --vacation-dark-blue: #1565c0;
            --vacation-green: #4caf50;
            --vacation-dark-green: #388e3c;
            --vacation-light: #f5f9fc;
            --vacation-dark: #0a2e5a;
        }
        
        body {
            background-color: var(--vacation-light);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding-top: 56px;
            color: #333;
        }
        
        .vacation-header {
            background: linear-gradient(135deg, var(--vacation-primary), var(--vacation-dark));
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-radius: 0 0 10px 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        .vacation-btn-primary {
            background-color: var(--vacation-primary);
            border-color: var(--vacation-primary);
            color: white;
        }
        
        .vacation-btn-primary:hover {
            background-color: var(--vacation-dark);
            border-color: var(--vacation-dark);
            color: white;
        }
        
        .vacation-btn-secondary {
            background-color: var(--vacation-secondary);
            border-color: var(--vacation-secondary);
            color: white;
        }
        
        .vacation-btn-secondary:hover {
            background-color: var(--vacation-primary);
            border-color: var(--vacation-primary);
            color: white;
        }
        
        .feature-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border: none;
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
            height: 100%;
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
        }
        
        .feature-icon {
            color: var(--vacation-primary);
            margin-bottom: 1rem;
        }
        
        .stat-card {
            transition: all 0.3s ease;
            border: none;
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        
        .stat-card:hover {
            transform: scale(1.03);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        }
        
        .navbar {
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            background-color: var(--vacation-dark) !important;
        }
        
        .navbar-brand img {
            height: 40px;
        }
        
        .dropdown-menu {
            border: none;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        
        .dropdown-item:hover {
            background-color: var(--vacation-light);
            color: var(--vacation-primary);
        }
        
        .background-section {
            position: relative;
            min-height: 60vh;
            background-attachment: fixed;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
            z-index: 0;
            padding: 80px 0;
            margin-bottom: 2rem;
        }
        
        .background-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(30, 136, 229, 0.3); /* Azules más claros y menos opacos */
            z-index: -1;
        }
        .custom-bg-section {
            background: url('./images/slider/3.jpg') no-repeat center center;
            background-size: cover;
            background-attachment: fixed;
            padding: 40px 0;
            position: relative;
            min-height: 400px; /* Ajusta según necesidad */
        }
        
        .custom-bg-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.3); /* Overlay claro (ajusta la opacidad) */
            z-index: 0;
        }
        
        .custom-bg-section .row {
            position: relative;
            z-index: 1; /* Asegura que el contenido esté sobre el overlay */
        }
        
        .content-overlay {
            position: relative;
            z-index: 1;
            color: white;
        }
        
        .section-title {
            color: white;
            font-weight: 700;
            margin-bottom: 1.5rem;
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.3);
        }
        
        .info-card {
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            height: 100%;
            transition: all 0.3s ease;
            border: 1px solid rgba(0, 0, 0, 0.05);
        }
        
        .info-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }
        
        .info-header {
            border-bottom: 2px solid var(--vacation-light);
            padding-bottom: 0.5rem;
            margin-bottom: 1rem;
        }
        
        .info-header h3 {
            color: var(--vacation-primary);
            font-weight: 600;
        }
        
        .table th {
            background-color: var(--vacation-primary);
            color: white;
        }
        
        .table-hover tbody tr:hover {
            background-color: rgba(13, 71, 161, 0.1);
        }
        
        .cta-section {
            background: linear-gradient(135deg, var(--vacation-primary), var(--vacation-dark)) !important;
            padding: 4rem 0;
            margin: 3rem 0;
            border-radius: 10px;
        }
        
        .animate-fadein {
            opacity: 0;
            animation: fadeIn 1.5s ease-in-out forwards;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Ajustes para el contenedor principal */
        .main-container {
            padding: 2rem 0;
        }
        
        /* Mejoras para la tabla de vuelos en vivo */
        #live_flights_table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }
        
        #live_flights_table th {
            position: sticky;
            top: 56px;
            z-index: 10;
        }
        
        /* Ajustes para móviles */
        @media (max-width: 768px) {
            .background-section {
                min-height: auto;
                padding: 40px 0;
            }
            
            .stat-card, .feature-card, .info-card {
                margin-bottom: 1.5rem;
            }
        }
    </style>
    
    <!-- Bootstrap JS y plugins -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="./index.php">
                <img src="./images/logo.png" alt="Vacation Air Logo" height="40">
                <span class="ms-2">Vacation Air</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="./index.php"><i class="fas fa-home"></i> <?php echo 'Home'; ?></a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="aboutDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-info-circle"></i> <?php echo ABOUT; ?>
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="aboutDropdown">
                            <li><a class="dropdown-item" href="./index.php?page=staff"><i class="fas fa-users"></i> <?php echo STAFF; ?></a></li>
                            <li><a class="dropdown-item" href="./index.php?page=rules"><i class="fas fa-file-alt"></i> <?php echo RULES; ?></a></li>
                            <li><a class="dropdown-item" href="./index.php?page=school"><i class="fas fa-graduation-cap"></i> <?php echo SCHOOL; ?></a></li>
                            <li><a class="dropdown-item" href="#"><i class="fas fa-comments"></i> <?php echo FORUM; ?></a></li>
                            <li><a class="dropdown-item" href="./index.php?page=pilot_register"><i class="fas fa-handshake"></i> <?php echo REGISTER; ?></a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="opsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-plane"></i> <?php echo OPERATIONS; ?>
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="opsDropdown">
                            <li><a class="dropdown-item" href="./index.php?page=fleet_public"><i class="fa fa-plane fa-fw"></i> <?php echo FLEET; ?></a></li>
                            <li><a class="dropdown-item" href="./index.php?page=route_public"><i class="fas fa-route"></i> <?php echo ROUTES; ?></a></li>
                            <li><a class="dropdown-item" href="./index.php?page=hubs"><i class="fas fa-map-marker-alt"></i> <?php echo HUBS; ?></a></li>
                            <li><a class="dropdown-item" href="./index.php?page=tours"><i class="fas fa-passport"></i> <?php echo TOURS; ?></a></li>
                            <li><a class="dropdown-item" href="./index.php?page=ranks"><i class="fas fa-bookmark"></i> <?php echo PILOT_RANKS; ?></a></li>
                            <li><a class="dropdown-item" href="./index.php?page=awards"><i class="fas fa-star"></i> <?php echo AWARDS; ?></a></li>
                            <li><a class="dropdown-item" href="./index.php?page=va_global_financial_report"><i class="fas fa-dollar-sign"></i> <?php echo GLOBAL_FINANCES; ?></a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./index.php?page=pilots_public"><i class="fas fa-user-astronaut"></i> <?php echo PILOTS; ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./index.php?page=stats"><i class="fas fa-chart-line"></i> <?php echo STATS; ?></a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="langDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-language"></i> <?php echo LANGUAGES; ?>
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="langDropdown">
                            <?php echo $linklanguage; ?>
                        </ul>
                    </li>
                </ul>
                
                <?php if ($user_logged == 0): ?>
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="./index.php?page=pilot_register"><i class="fas fa-user-plus"></i> Register</a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-outline-light ms-2" href="#" data-bs-toggle="modal" data-bs-target="#loginModal"><i class="fas fa-sign-in-alt"></i> Login</a>
                        </li>
                    </ul>
                <?php else: ?>
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($_SESSION['user']); ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="./index_vam.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                                <li><a class="dropdown-item" href="https://vacationairva.com/vam/index_vam_op.php?page=pilot_options"><i class="fas fa-user"></i> My Profile</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="./index.php?page=logout"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Login Modal -->
    <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="loginModalLabel">Pilot Login</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="loginForm" action="./login.php" method="post">
                        <div class="mb-3">
                            <label for="loginCallsign" class="form-label">Callsign</label>
                            <input type="text" class="form-control" id="loginCallsign" name="user" placeholder="VA-XXX" required>
                        </div>
                        <div class="mb-3">
                            <label for="loginPassword" class="form-label">Password</label>
                            <input type="password" class="form-control" id="loginPassword" name="password" required>
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="rememberMe">
                            <label class="form-check-label" for="rememberMe">Remember me</label>
                        </div>
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Login</button>
                        </div>
                    </form>
                </div>
                <div class="modal-footer justify-content-center bg-light">
                    <p class="mb-0">New to Vacation Air? <a href="./index.php?page=pilot_register" data-bs-dismiss="modal">Register here</a></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content Container -->
    <div class="container main-container mt-4">